onEvent("buttonmainscreen", "click", function(event) {
  setScreen("quotescreen");
});
onEvent("quotescreen", "click", function(event) {
  setScreen("whoareyou?");
});
onEvent("iamyou", "click", function(event) {
  setScreen("Iamyou");
});
onEvent("triangle", "click", function(event) {
  setScreen("iamhuman");
});
onEvent("next1", "click", function(event) {
  setScreen("ofcourse");
});
onEvent("next2", "click", function(event) {
  setScreen("amyou-scene1");
});
onEvent("answer", "click", function(event) {
  setScreen("amyou-scene2");
});
onEvent("next3", "click", function(event) {
  setScreen("amyou-scene3");
});
onEvent("next4", "click", function(event) {
  setScreen("amyou-scene4");
});
onEvent("next5", "click", function(event) {
  setScreen("amyou-scene5");
});
onEvent("next6", "click", function(event) {
  setScreen("amyou-scene7");
});
onEvent("next7", "click", function(event) {
  setScreen("amyou-scene9");
});
